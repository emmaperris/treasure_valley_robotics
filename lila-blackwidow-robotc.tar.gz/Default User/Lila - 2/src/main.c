#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(3, 50);
    msleep(3500);
    motor(0, 0);
    motor(3, 25);
    msleep(2500);
    motor(0, 50);
    motor(3, 50);
    msleep(1900);
    motor(0, 50);
    motor(3, 15);
    msleep(11750);
    motor(0, 50);
    motor(3, 50);
    msleep(7750);
    
    printf("Hello World\n");
    return 0;
}
