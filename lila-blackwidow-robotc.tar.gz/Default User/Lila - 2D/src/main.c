#include <kipr/wombat.h>

int main()
{
    //drive to spot #4
    printf("driving to spot #4\n");
    motor(3, 50);
    motor(0, 51.5);
    msleep(3000);
    
    //turn and drive near spot #7
    printf("turing towards spot #7\n");
    motor(3, 35);
    motor(0, 0);
    msleep(2200);
    printf("driving a little bit\n");
    motor(3, 50);
    motor(0, 51.5);
    msleep(1500);
    
    //making the big turn forward
    printf("making the big turn forward\n");
    motor(3, 20);
    motor(0, 50);
    msleep(18750);
    
    //tank turn #1
    printf("making tank turn #1\n");
    motor(3, -50);
    motor(0, 51.1);
    msleep(3250);
    
    //making the big turn backward
    printf("making the big turn backward\n");
    motor(3, -50);
    motor(0, -20);
    msleep(21000);
    
    //tank turn #2
    printf("making tank turn #2\n");
    motor(3, -50);
    motor(0, 51.5);
    msleep(2100);
    
    //drive to start
    printf("driving to start\n");
    motor(3, 50);
    motor(0, 51.5);
    msleep(5000);
    
    printf("CHALLENGE COMPLETE\n");
    return 0;
}
