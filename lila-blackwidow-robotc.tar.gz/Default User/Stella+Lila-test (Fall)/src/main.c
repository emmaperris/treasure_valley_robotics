#include <kipr/wombat.h>

int main()
{
    motor(0, 51.5);
    motor(3, -50);
    msleep(1500);
    motor(0, 51.5);
    motor(3, 50);
    msleep(4500);
    motor(0, -51.5);
    motor(3, 50);
    msleep(1450);
    motor(0, 51.5);
    motor(3, 50);
    msleep(14500);
    motor(0, 51.5);
    motor(3, 25);
    msleep(2500);
    motor(0, 51.5);
    motor(3, -50);
    msleep(850);
    motor(0, 50);
    msleep(500);
    
    printf("Hello World\n");
    return 0;
}
