#include <kipr/wombat.h>

void drive(int centimeters) {
	motor(0, 50);
    motor(3, 50);
    msleep(3000);
}