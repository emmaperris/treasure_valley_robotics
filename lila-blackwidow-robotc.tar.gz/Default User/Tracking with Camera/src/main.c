#include <kipr/wombat.h>

#include "drive.h"

int main()
{
    // connects to the camera.
    camera_open();

    // Turn until you see the red block. 
    while(1) {

        // Gets a new image.
        camera_update();

        // We are turning until we see an object.
        if (get_object_count(0) == 0) {
            motor(0,50);
            motor(3,-50);
            msleep(20);
        } else {
            printf("%d is the width of the largest object.\n", get_object_bbox_width(0,0));
            if (get_object_center_x(0,0) > 320) {
                motor(0,20);
                motor(3,-20);
                msleep(20);
            }
            
        }

            // If we are not at the center of the object we are turning until we are at the center of the object.
            /*
        	if(get_object_center_x(0,0) > 320) {
                motor(0,20);
                motor(3,-20);
                msleep(20);
            }
            */
        
        printf("%d is the center of the red block.\n", get_object_center_x(0,0));
        ao();
    }
    // Cut off connection to the camera.
    camera_close();

    return 0;
}
