#include <kipr/wombat.h>

#define LEFTMOTOR 3
#define SECOND 1000
#define RIGHTMOTOR 0
#define HALFPOWERleft 50
#define HALFPOWERright 51.5
#define HALFPOWERBACKWARDSright -51.5
#define HALFPOWERBACKWARDSleft -50

int main()
{
    //drive out of start
    motor(LEFTMOTOR, HALFPOWERleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 2.5);
    printf("Out Of Start\n");
    
    //tank turn
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 3.17);
    printf("Tank Turned\n");
    
    //back into parking spot
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    msleep(SECOND * 3.25);
    printf("Parked!\n");
    ao();
    msleep(SECOND * 0.5);
        
    //back to start
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 6);
    printf("Back At Start\n");
    
    //tank turn 
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    msleep(SECOND * 3.3);
    printf("Tank Turned\n");
    
    //drive up to blue garage
    motor(LEFTMOTOR, HALFPOWERleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 8.85);
    printf("At Blue Garage\n");
    
    //partial tank turn
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 2.27);
    printf("Partially Tank Turned\n");
    
    //back into garage
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    msleep(SECOND * 3.3);
    printf("Parked!\n");

    //get out of garage
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 1.5);
    printf("Out Of Garage\n");
    
    //gradually turn
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, 27.5);
    msleep(SECOND * 4);
    printf("Gradually Turned\n");
    
    //back to start
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 7.25);
    printf("Back At Start\n");
    
    printf("CHALLENGE COMPLETE\n");
    return 0;
}
