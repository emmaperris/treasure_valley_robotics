#include <kipr/wombat.h>

#define SECOND 1000
#define LEFTMOTOR 3
#define RIGHTMOTOR 0
#define HALFPOWERleft 50
#define HALFPOWERright 51.5
#define HALFPOWERBACKWARDSleft -50
#define HALFPOWERBACKWARDSright -51.5

int main()

{
    //drive out
	motor(LEFTMOTOR, HALFPOWERleft);
	motor(RIGHTMOTOR, HALFPOWERright);
	msleep(SECOND * 3.5);
    printf("Drove Out\n");
    
    //tank turn
    motor(LEFTMOTOR, HALFPOWERleft);
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    msleep(SECOND * 1.65);
    printf("Tank Turn Complete\n");
    
    //drive a bit (can't touch the walls)
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 2.7);
    printf("Drove a Bit\n");
    
    //tank turn
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    msleep(SECOND * 1.65);
    printf("Tank Turn Complete\n");
    
    //get in parking position
    motor(LEFTMOTOR, HALFPOWERleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 6);
    printf("In Position\n");
    
    //parallel park
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    msleep(SECOND * 3);
    ao();
    msleep(SECOND * 1);
    printf("Parellel Parked\n");
    
    //back up to start
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    msleep(SECOND * 6.25);
    printf("First Run Completed!");
    
    //tank turn
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 1.5);
    printf("Tank Turn Complete\n");
    
    //drive to other side of start
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 2.5);
    printf("At The Other End Of Start\n");
    
    //big, gradual turn
    motor(LEFTMOTOR, HALFPOWERleft);
    motor(RIGHTMOTOR, 27);
    msleep(SECOND * 6.35);
    printf("Gradual Turn Completed\n");
    
    //get in position #2
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 6.5);
    printf("In Position\n");
    
    //parallel park
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    msleep(SECOND * 3);
    printf("Parallel Parked!\n");
    ao();
    msleep(SECOND);
    
    //go back to start
    motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    msleep(SECOND * 6);
    printf("Back At Start\n");

    printf("CHALLENGE COMPLETE\n");
    return 0;
}
