#include <kipr/wombat.h>

#define SECOND 1000
#define LEFTMOTOR 3 
#define RIGHTMOTOR 0
#define HALFPOWERleft 51.5 
#define HALFPOWERright 50
#define HALFPOWERBACKWARDSright -50
#define HALFPOWERBACKWARDSleft -51.5
#define TOPHATright 0
#define TOPHATleft 1
#define CHANNEL_SERVO 0
#define BLACK 3100
#define LEVERBUMPSENSOR 2
#define CHANNEL_UP 750
#define CHANNEL_DOWN 50
#define FULLCLAWHEIGHT 5100
#define CLAWOPERATIONMOTOR 2
#define CLAWHEIGHTMOTOR 1
#define HALFPOWERclaw 50
#define HALFPOWERBACKWARDSclaw -50
#define CLAWROTATION 7250
#define LIGHTSENSOR 5
#define CENTIMETER 82

void advanced_set_servo_position(int destination) {
    if(get_servo_enabled(CHANNEL_SERVO)) {
        set_servo_position(CHANNEL_SERVO, destination);
    } else {
        set_servo_position(CHANNEL_SERVO, destination);
        enable_servos();
    }
}

void smooth_servo(int destination) {
    int current_servo_position = 0;
    int increment = 20;
    current_servo_position = get_servo_position(CHANNEL_SERVO);

    if(current_servo_position < destination) {
        while(current_servo_position < destination) {
            if (current_servo_position + increment < destination) {
                advanced_set_servo_position(current_servo_position + increment);
            } else {
                advanced_set_servo_position(destination + 5);
            }
            current_servo_position = get_servo_position(CHANNEL_SERVO);
            msleep(SECOND * 0.1);
        }
    }
    if(current_servo_position > destination) {
        while(current_servo_position > destination) {
            if (current_servo_position - increment > destination) {
                advanced_set_servo_position(current_servo_position - increment);
            } else {
                advanced_set_servo_position(destination - 5);
            }
            current_servo_position = get_servo_position(CHANNEL_SERVO);
            msleep(SECOND * 0.1);
        }
    }
}
void channel_up() {
    set_servo_position(CHANNEL_SERVO, 400);
    smooth_servo(CHANNEL_UP);
    disable_servos();
}

void channel_down() {
    set_servo_position(CHANNEL_SERVO, 400);
    smooth_servo(CHANNEL_DOWN);
    disable_servos();
}

void claw_up(int rotations) {
    printf("hello\n");
    clear_motor_position_counter(CLAWHEIGHTMOTOR);
    while(get_motor_position_counter(CLAWHEIGHTMOTOR) < rotations) {
        motor(CLAWHEIGHTMOTOR, HALFPOWERclaw);
        msleep(SECOND * 0.2);
    }
    ao();
}


void claw_down(int rotations) {
    clear_motor_position_counter(CLAWHEIGHTMOTOR);
    while(get_motor_position_counter(CLAWHEIGHTMOTOR) > rotations * -1) {
        motor(CLAWHEIGHTMOTOR, HALFPOWERclaw * -1);
        msleep(SECOND * 0.2);
    }
    ao();
}

void close_claw() {
    clear_motor_position_counter(CLAWOPERATIONMOTOR);
    while(get_motor_position_counter(CLAWOPERATIONMOTOR) > CLAWROTATION * -1) {
        printf("%d\n", get_motor_position_counter(CLAWOPERATIONMOTOR));
        motor(CLAWOPERATIONMOTOR, HALFPOWERclaw * -1);
        msleep(SECOND * 0.2);
    }
    ao();
}

void open_claw() {
    clear_motor_position_counter(CLAWOPERATIONMOTOR);
    while(get_motor_position_counter(CLAWOPERATIONMOTOR) < CLAWROTATION) {
        printf("%d\n", get_motor_position_counter(CLAWOPERATIONMOTOR));
        motor(CLAWOPERATIONMOTOR, HALFPOWERclaw);
        msleep(SECOND * 0.2);
    }
    ao();
}

void follow_until_bump() {
    while(digital(LEVERBUMPSENSOR) == 0) {
        if(analog(TOPHATright) < BLACK) {
            motor(RIGHTMOTOR, HALFPOWERright);
            motor(LEFTMOTOR, 0);
            msleep(SECOND * 0.2);
        }

        if(analog(TOPHATleft) < BLACK) {
            motor(LEFTMOTOR, HALFPOWERleft);
            motor(RIGHTMOTOR, 0);
            msleep(SECOND * 0.2);
        }
    }
    ao();
}

void drive_until_left_white() {
    while(analog(TOPHATleft) > BLACK) {
        motor(RIGHTMOTOR, 31.5);
        motor(LEFTMOTOR, 30);
        msleep(SECOND * 0.2);
    }
    printf("White!\n");
    ao();
}

void drive_until_both_white() {
    while(analog(TOPHATright) > BLACK || analog(TOPHATleft) > BLACK) {
        printf("analog0: %d  analog1: %d black: %d\n", analog(TOPHATright), analog(TOPHATleft), BLACK);
        motor(LEFTMOTOR, HALFPOWERleft);
        motor(RIGHTMOTOR, HALFPOWERright);
        msleep(SECOND * 0.2);
    }
    ao();
}

void drive_until_left_black() {
    while(analog(TOPHATleft) < BLACK) {
        motor(RIGHTMOTOR, HALFPOWERright);
        motor(LEFTMOTOR, HALFPOWERleft);
        msleep(SECOND * 0.2);
    }
    ao();
}

void follow_until_both_black() {
    while(analog(TOPHATleft) < BLACK || analog(TOPHATright) < BLACK) {
        if(analog(TOPHATleft) < BLACK && analog(TOPHATright) < BLACK) {
            motor(RIGHTMOTOR, 40);
            motor(LEFTMOTOR, 41.5);
            msleep(SECOND * 0.1);
        }

        if(analog(TOPHATright) > BLACK) {
            motor(RIGHTMOTOR, 0);
            motor(LEFTMOTOR, HALFPOWERleft);
            msleep(SECOND * 0.1);
        }

        if(analog(TOPHATleft) > BLACK) {
            motor(LEFTMOTOR, 0);
            motor(RIGHTMOTOR, HALFPOWERright);
            msleep(SECOND * 0.1);
        }
    }
    ao();
    printf("Both on black!\n");
}

void check_if_sensor_on_black() {
    printf("Checking...\n");

    while(analog(TOPHATleft) > BLACK) {
        printf("I see black on left!\n");
        motor(LEFTMOTOR, 0);
        motor(RIGHTMOTOR, HALFPOWERright);
        msleep(SECOND * 0.2);
    }
    ao();

    while(analog(TOPHATright) > BLACK) {
        printf("I see black on right!\n");
        motor(RIGHTMOTOR, 0);
        motor(LEFTMOTOR, HALFPOWERleft);
        msleep(SECOND * 0.2);
    }
    ao();
    printf("Checked!\n");
}

void turn_until_left_black() {
    printf("On the line!\n");    
    while(analog(TOPHATleft) < BLACK) {
        motor(LEFTMOTOR, 30);
        motor(RIGHTMOTOR, -31.5);
        msleep(SECOND * 0.2);
    }
    ao();
}

void turn_around_backwards() {
    while(analog(TOPHATleft) < BLACK) {
        motor(LEFTMOTOR, HALFPOWERleft);
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.2);
    }
    ao();

    while(analog(TOPHATleft) > BLACK) {
        motor(LEFTMOTOR, HALFPOWERleft);
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.2);
    }
    ao();

    while(analog(TOPHATleft) < BLACK) {
        motor(LEFTMOTOR, HALFPOWERleft);
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.2);
    }
    ao();
    
    while(analog(TOPHATleft) > BLACK) {
        motor(LEFTMOTOR, HALFPOWERleft);
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.2);
    }
    ao(); 
}

void turn_onto_potato_line() {
    while(analog(TOPHATright) > BLACK) {
        motor(RIGHTMOTOR, HALFPOWERright);
        motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
        msleep(SECOND * 0.2);
    }
    ao();

    while(analog(TOPHATright) < BLACK) {
        motor(RIGHTMOTOR, HALFPOWERright);
        motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
        msleep(SECOND * 0.2);
    }
    ao();
}

void tank_turn_ninety_degree_left() {
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 1.67);
    ao();
}

void less_than_tank_turn_ninety_degree_left() {
    motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
    motor(RIGHTMOTOR, HALFPOWERright);
    msleep(SECOND * 1.33);
    ao();
}

void drive_over_bump() {
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 1.5);
    ao();
}

void drive_until_either_white() {
    while(analog(TOPHATright) > BLACK && analog(TOPHATleft) > BLACK) {
        printf("analog0: %d  analog1: %d black: %d\n", analog(TOPHATright), analog(TOPHATleft), BLACK);
        motor(RIGHTMOTOR, HALFPOWERright);
        motor(LEFTMOTOR, HALFPOWERleft);
        msleep(SECOND * 0.2);
    }
    ao();
}

void follow_until_black_left_backwards() {
    while(analog(TOPHATleft) < BLACK) {
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
        msleep(SECOND * 0.5);
        if(analog(TOPHATright) > BLACK) {
            motor(RIGHTMOTOR, 0);
            motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
            msleep(SECOND * 0.1);
            printf("blackright\n");
        }

        if(analog(TOPHATleft) > BLACK) {
            motor(LEFTMOTOR, 0);
            motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
            msleep(SECOND * 0.1);
            printf("blackleft\n");
        }
    }
    ao();
    printf("Both on black!\n");
}

void follow_black_line_for_some_time(int time) {
    int current_time = 0;
    time = time * SECOND;
    while(current_time < time) {
        if(analog(TOPHATleft) < BLACK && analog(TOPHATright) < BLACK) {
            motor(RIGHTMOTOR, 40);
            motor(LEFTMOTOR, 41.5);
            msleep(SECOND * 0.1);
            current_time = current_time + (SECOND * 0.1);
        }

        if(analog(TOPHATright) > BLACK) {
            motor(RIGHTMOTOR, 0);
            motor(LEFTMOTOR, HALFPOWERleft);
            msleep(SECOND * 0.1);
            current_time = current_time + (SECOND * 0.1);
        }

        if(analog(TOPHATleft) > BLACK) {
            motor(LEFTMOTOR, 0);
            motor(RIGHTMOTOR, HALFPOWERright);
            msleep(SECOND * 0.1);
            current_time = current_time + (SECOND * 0.1);
        }
    }
    ao();
    printf("Have finished following the line!\n");
}

void reverse_into_position(int centimeters) {
    clear_motor_position_counter(LEFTMOTOR);
    clear_motor_position_counter(RIGHTMOTOR);
    int current_amount = 0;
    while(current_amount < (centimeters * CENTIMETER)) {
        motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.1);
        current_amount = -(get_motor_position_counter(LEFTMOTOR));
    }
    ao();
}

void perfectly_align() {
    while(analog(TOPHATright) < BLACK) {
        motor(LEFTMOTOR, HALFPOWERBACKWARDSleft);
        msleep(SECOND * 0.1);
    }
    
    while(analog(TOPHATright) > BLACK) {
        motor(LEFTMOTOR, 15);
        msleep(SECOND * 0.1);
    }
    
    motor(LEFTMOTOR, 30);
    msleep(SECOND * 0.3);
    ao();
}

void perfectly_align_2() {
    while(analog(TOPHATleft) < BLACK) {
        motor(RIGHTMOTOR, HALFPOWERBACKWARDSright);
        msleep(SECOND * 0.1);
    }
    
    while(analog(TOPHATleft) > BLACK) {
        motor(RIGHTMOTOR, 15);
        msleep(SECOND * 0.1);
    }
}

int main()
{ 
    printf("Running wait_for_light!\n");
    wait_for_light(LIGHTSENSOR);
	
    shut_down_in(119);

    printf("Running channel_up!\n");
    channel_up();

    printf("Running tank_turn_ninety_degree_left\n");
    tank_turn_ninety_degree_left();

    printf("Running drive_until_left_black!\n");
    drive_until_left_black();

    printf("Running drive_until_left_white!\n");
    drive_until_left_white();
    
    printf("Running drive_until_left_black!\n");
    drive_until_left_black();

    printf("Running drive_until_both_white!\n");
    drive_until_both_white();

    printf("Running turn_until_left_black!\n");
    turn_until_left_black();

    printf("Running follow_until_both_black!\n");
    follow_until_both_black();
    
    printf("Running drive_until_both_white!\n");
    drive_until_both_white();

    printf("Running drive_over_bump!\n");
    drive_over_bump();

    printf("Running check_if_sensor_on_black!\n");
    check_if_sensor_on_black();

    printf("Running follow_until_both_black!\n");
    follow_until_both_black();

    printf("Running drive_until_either_white!\n");
    drive_until_either_white();

    printf("Running less_than_tank_turn_ninety_degree_left!\n");
    less_than_tank_turn_ninety_degree_left();
    
    printf("Running follow_until_bump!\n");
    follow_until_bump();
    
    printf("Running reverse_into_position!\n");
    reverse_into_position(7);
    
    printf("Running perfectly_align!\n");
    perfectly_align();
    
    printf("Running claw_down!\n");
    claw_down(FULLCLAWHEIGHT * 0.6);
    
    printf("Running close_claw!\n");
    close_claw(CLAWROTATION);
    
    printf("Running claw_up!\n");
    claw_up(FULLCLAWHEIGHT);
    
	printf("Running turn_around_backwards!\n");
    turn_around_backwards();
    
    printf("Running follow_black_line_for_some_time!\n");
    follow_black_line_for_some_time(6);
    
    printf("Running perfectly_align_2!\n");
    perfectly_align_2();
    
    printf("Running open_claw!\n");
    open_claw(CLAWROTATION);

    //follow_until_2black();

    //drive_until_white();

    //follow_until_2black();

    //drive_until_white();

    //follow_until_bump();

    return 0;
}
