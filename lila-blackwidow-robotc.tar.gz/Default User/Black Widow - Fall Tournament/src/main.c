#include <kipr/wombat.h>

#define SECOND 1000
#define LEFTMOTOR 3
#define RIGHTMOTOR 0
#define HALFPOWERleft 50
#define HALFPOWERright 51.5
#define HALFPOWERBACKWARDSright -51.5
#define HALFPOWERBACKWARDSleft -50
#define PLOWDOWN 210
#define PLOWUP 1340
#define TOPHAT 0
#define PLOWSERVO 0
#define BLACK 0
#define WHITE 1
#define FRONTBUMPSENSOR 9
#define RIGHTBACKBUMPSENSOR 2
#define LEFTBACKBUMPSENSOR 3
#define LIGHTSENSOR 0

int main()
{
    //wait for light
    wait_for_light(LIGHTSENSOR);
    
    shut_down_in(119);

    //check the servos
    enable_servos();
    int current_servo_position = get_servo_position(PLOWSERVO);
    while(current_servo_position > PLOWDOWN) {
        set_servo_position(PLOWSERVO, current_servo_position - 20);
        current_servo_position = get_servo_position(PLOWSERVO);
        msleep(100);
    }
    disable_servos();

    //drive until starting box ends
    while(digital(TOPHAT) == 1) {
        motor(RIGHTMOTOR, 45);
        msleep(SECOND * 0.2);
    }
    printf("Black!\n");
    ao();
    
    //drive until white
    while(digital(0) == 0) {
        motor(RIGHTMOTOR, 31.5);
        motor(LEFTMOTOR, 30);
        msleep(SECOND * 0.2);
    }
    printf("White!\n");
    ao();

    //drive until wheel passes start line
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 0.5);
    ao();

    float timer = 0;
    //follow the black line while pushing the water to the black line
    while (timer < 87) {

        if(digital(TOPHAT) == WHITE) {
            motor(LEFTMOTOR, HALFPOWERleft);
            msleep(SECOND * 0.05);
            ao();
        }
        if(digital(TOPHAT) == BLACK) {
            motor(RIGHTMOTOR, HALFPOWERright);
            msleep(SECOND * 0.05);
            ao();
        }
        timer = timer + 0.2;
        printf("%f\n", timer);
    }

    //raise the plow
    enable_servos();
    while(current_servo_position < PLOWUP) {
        set_servo_position(PLOWSERVO, current_servo_position + 35);
        current_servo_position = get_servo_position(PLOWSERVO);
        msleep(100);
    }
    disable_servos();

    //hit the bump sensor
    while(digital(FRONTBUMPSENSOR) < 1) {
        motor(RIGHTMOTOR, 35);
        motor(LEFTMOTOR, 65);
        msleep(SECOND * 0.2);
    }
    
    printf("RUN COMPLETED!!!\n");

    return 0;
}
