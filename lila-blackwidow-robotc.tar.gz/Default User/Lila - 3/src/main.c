#include <kipr/wombat.h>

int main()
{
    //parking in green garage
    motor(3, 50);
    motor(0, 51.5);
    msleep(6500);
    ao();
    msleep(500);
    printf("parked in green garage\n");
    
    //back to start
    motor(3, -50);
    motor(0, -51.5);
    msleep(6500);
    printf("back at start\n");
    
    //drive a little bit
    motor(3, 50);
    motor(0, 51.5);
    msleep(3000);
    printf("drove a bit\n");
        
    //tank turn
    motor(3, -50);
    motor(0, 51.5);
    msleep(1450);
    
    //slow turn
    motor(3, 50);
    motor(0, 36.5);
    msleep(10000);
    printf("made the turn\n");
    
    //drive slightly
    motor(3, 50);
    motor(0, 51.5);
    msleep(1500);
    printf("drove slightly\n");
    
    //parking into yellow garage
    motor(0, 9);
    motor(3, 50);
    msleep(7500);
    printf("almost there\n");
    motor(0, 51.5);
    motor(3, 50);
    msleep(1300);
    ao();
    msleep(500);
    printf("parked in yellow garage\n");
    
    //backing to turn spot
    motor(0, -51.5);
    motor(3, -50);
    msleep(1500);
    printf("out of garage\n");
    motor(0, -10);
    motor(3, -50);
    msleep(8000);
    printf("in turning position\n");
    
    //slow turn backwards
    printf("making the slow turn backwards\n");
    motor(3, -50);
    motor(0, -45);
    msleep(10000);
    
    //slight turn
    motor(0, -51.5);
    motor(3, 0);
    msleep(1500);
    printf("turned slightly\n");
    
    //back to start for good
    motor(3, -50);
    motor(0, -51.5);
    msleep(900);
    printf("at start\n");
    
    //printf("CHALLENGE COMPLETE\n");
    return 0;
}
