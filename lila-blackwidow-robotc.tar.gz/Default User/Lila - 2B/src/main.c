#include <kipr/wombat.h>

int main()
{
    //drive to spot #9
    motor(0, 51.5);
    motor(3, 50);
    msleep(7750);
    
    //turn and drive to spot #12
    motor(3, 35);
    motor(0, 1.5);
    msleep(3350);
    motor(3, 50);
    motor(0, 51.5);
    msleep(2500);
    
    //make the first big turn
    motor(3, 27.5);
    motor(0, 51.5);
    msleep(12000);
    
    //pass spot #11
    motor(3, 50);
    motor(0, 51.5);
    msleep(2500);
    
    //make the second big turn
    motor(3, 27.5);
    motor(0, 45);
    msleep(12500);
    
    //go back to start
    motor(3, 50);
    motor(0, 51.5);
    msleep(7250);
    motor(0, 0);
    motor(3, 37.5);
    msleep(1250);
    motor(3, 50);
    motor(0, 51.5);
    msleep(3650);
    
    printf("Challenge Complete\n");
    return 0;
}
