#include <kipr/wombat.h>

#define SECOND 1000
#define LEFTMOTOR 3
#define RIGHTMOTOR 0
#define HALFPOWERleft 50
#define HALFPOWERright 51.5
#define HALFPOWERBACKWARDSleft -50
#define HALFPOWERBACKWARDSright -51.5

int main()
{
    //start at coordinates (o, -4)
    //drive a bit
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR,HALFPOWERleft);
    msleep(SECOND * 3.5);
    
    //gradual turn #1
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, 30);
    msleep(SECOND * 4.5);
    
    //drive up
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 3);
    
    //big gradual turn
    motor(RIGHTMOTOR, 15);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 13.5);
    
    //drive down 
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 3);
    
    //gradual turn #2
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, 30);
    msleep(SECOND * 3.5);
    
    //drive home
    motor(RIGHTMOTOR, HALFPOWERright);
    motor(LEFTMOTOR, HALFPOWERleft);
    msleep(SECOND * 4);
    
    //printf("CHALLENGE COMPLETE\n");
    return 0;
}
