#include <kipr/wombat.h>

int main()
{
    //drive to spot #4
    motor(3, 50);
    motor(0, 51.5);
    msleep(3000);
    ao();
    msleep(250);
    
    //tank turn #1+
    motor(3, 50);
    motor(0,-51.5);
    msleep(4000);
    
    //drive a little bit
    motor(3, -50);
    motor(0, -51.5);
    msleep(2000);
    
    //big, gradual, awesome turn
    motor(3, -50);
    motor(0, -20);
    msleep(15500);
    
    //tank turn #2
    motor(3, 50);
    motor(0, -51.5);
    msleep(4000);
    
    //drive to start
    motor(3, 50);
    motor(0, 51.5);
    msleep(5000);
    
    printf("Challenge Complete\n");
    return 0;
}
