#include <kipr/wombat.h>

#define HALFPOWER 50
#define HALFPOWERBACK -50
#define STOP 0
#define FULLPOWER 100
#define FULLPOWERBACK -100
#define BLACK 3900
#define SECOND 1000
#define MOTORLEFT 2
#define MOTORRIGHT 1
#define TOPHATLEFT 2
#define TOPHATRIGHT 1
#define SWATSERVO 0

//Follow the black line with the right sensor until sensor hits the perpendicular black line.
void follow_right_until_both_on_black() {
    while(analog(TOPHATLEFT) < BLACK) { 
        if(analog(TOPHATRIGHT) > BLACK) {
            motor(MOTORLEFT, STOP);
            motor(MOTORRIGHT, HALFPOWER);
            msleep(SECOND * 0.2);
        }

        if(analog(TOPHATRIGHT) < BLACK) {
            motor(MOTORRIGHT, STOP);
            motor(MOTORLEFT, HALFPOWER);
            msleep(SECOND * 0.2);
        }
    }

    if(analog(TOPHATLEFT) > BLACK) {
        ao();
    }
}


//Drive over the perpendicular black line.
void drive_until_both_white() {
    while(analog(TOPHATRIGHT) > BLACK || analog(TOPHATLEFT) > BLACK) {
        printf("analog0: %d  analog1: %d black: %d\n", analog(TOPHATRIGHT), analog(TOPHATLEFT), BLACK);
        motor(MOTORLEFT, HALFPOWER);
        motor(MOTORRIGHT, HALFPOWER);
        msleep(SECOND * 0.2);
    }
    ao();
}


//Swat away the traffic cone.
void swat_the_traffic_cone() {
    int swat_has_been_run = 0;
    enable_servos();

    if(swat_has_been_run == 0) {
        set_servo_position(SWATSERVO, 1500);
        msleep(SECOND * 0.5);
        swat_has_been_run = 1;
    }

    if(swat_has_been_run == 1) {
        set_servo_position(SWATSERVO, 525);
        msleep(SECOND * 0.5);
    }
    disable_servos();
}


//Drive until hit the black line.
void drive_until_both_on_black() {

    while(analog(TOPHATLEFT) < BLACK || analog(TOPHATRIGHT) < BLACK) {

        if(analog(TOPHATLEFT) < BLACK) {
            motor(MOTORLEFT, HALFPOWER);
            msleep(SECOND * 0.15);
        }

        if(analog(TOPHATRIGHT) < BLACK) {
            motor(MOTORRIGHT, HALFPOWER);
            msleep(SECOND * 0.15);
        }

    }

}

int main()
{
    drive_until_both_on_black();
    
    drive_until_both_white();
    
    follow_right_until_both_on_black();
    
    drive_until_both_on_black();
    
    swat_the_traffic_cone()
    
    //printf("RUN COMPLETE!\n");
    return 0;
}
