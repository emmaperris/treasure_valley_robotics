#include <kipr/wombat.h>

#define SECOND 1000
#define LEFTMOTOR 3 
#define RIGHTMOTOR 0
#define HALFPOWERleft 51.5 
#define HALFPOWERright 50
#define HALFPOWERBACKWARDSright -50
#define HALFPOWERBACKWARDSleft -51.5
#define TOPHATright 0
#define TOPHATleft 1
#define CHANNEL_SERVO 0
#define BLACK 2500
#define LEVERBUMPSENSOR 2
#define CHANNEL_UP 750
#define CHANNEL_DOWN 50
#define FULLCLAWHEIGHT 5040
#define CLAWOPERATIONMOTOR 2
#define CLAWHEIGHTMOTOR 1
#define HALFPOWERclaw 50
#define HALFPOWERBACKWARDSclaw -50
#define CLAWROTATION 11390
#define LIGHTSENSOR 5

void advanced_set_servo_position(int destination) {
    if(get_servo_enabled(CHANNEL_SERVO)) {
        set_servo_position(CHANNEL_SERVO, destination);
    } else {
        set_servo_position(CHANNEL_SERVO, destination);
        enable_servos();
    }
}

void smooth_servo(int destination) {
    int current_servo_position = 0;
    int increment = 20;
    current_servo_position = get_servo_position(CHANNEL_SERVO);

    if(current_servo_position < destination) {
        while(current_servo_position < destination) {
            if (current_servo_position + increment < destination) {
                advanced_set_servo_position(current_servo_position + increment);
            } else {
                advanced_set_servo_position(destination + 5);
            }
            current_servo_position = get_servo_position(CHANNEL_SERVO);
            msleep(SECOND * 0.1);
        }
    }
    if(current_servo_position > destination) {
        while(current_servo_position > destination) {
            if (current_servo_position - increment > destination) {
                advanced_set_servo_position(current_servo_position - increment);
            } else {
                advanced_set_servo_position(destination - 5);
            }
            current_servo_position = get_servo_position(CHANNEL_SERVO);
            msleep(SECOND * 0.1);
        }
    }
}

void channel_down() {
    smooth_servo(CHANNEL_DOWN);
    disable_servos();
}

void claw_up(int rotations) {
    clear_motor_position_counter(CLAWHEIGHTMOTOR);
    while(get_motor_position_counter(CLAWHEIGHTMOTOR) < rotations) {
        motor(CLAWHEIGHTMOTOR, HALFPOWERclaw);
        msleep(SECOND * 0.2);
        printf("%d\n", get_motor_position_counter(CLAWHEIGHTMOTOR));
    }
    ao();
}


void claw_down(int rotations) {
    clear_motor_position_counter(CLAWHEIGHTMOTOR);
    while(get_motor_position_counter(CLAWHEIGHTMOTOR) > rotations * -1) {
        motor(CLAWHEIGHTMOTOR, HALFPOWERclaw * -1);
        msleep(SECOND * 0.2);
    }
    ao();
}

void close_claw(int rotations) {
    clear_motor_position_counter(CLAWOPERATIONMOTOR);
    while(get_motor_position_counter(CLAWOPERATIONMOTOR) > rotations * -1) {
        printf("%d\n", get_motor_position_counter(CLAWOPERATIONMOTOR));
        motor(CLAWOPERATIONMOTOR, HALFPOWERclaw * -1);
        msleep(SECOND * 0.2);
    }
    ao();
}

void open_claw(int rotations) {
    clear_motor_position_counter(CLAWOPERATIONMOTOR);
    while(get_motor_position_counter(CLAWOPERATIONMOTOR) < rotations) {
        printf("%d\n", get_motor_position_counter(CLAWOPERATIONMOTOR));
        motor(CLAWOPERATIONMOTOR, HALFPOWERclaw);
        msleep(SECOND * 0.2);
    }
    ao();
}

void channel_up() {
    set_servo_position(CHANNEL_SERVO, 400);
    smooth_servo(CHANNEL_UP);
    disable_servos();
}

int main()
{
	channel_down();
    
    //close_claw(800);

    printf("Reset Complete!\n");
    return 0;
}
