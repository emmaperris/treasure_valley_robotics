#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(9500);
    motor(0, -50);
    motor(2, -50);
    msleep(3000);
    printf("Hello World\n");
    return 0;
}
