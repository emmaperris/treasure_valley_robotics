#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(5000);
    motor(0, -100);
    motor(2, 1000);
    msleep(5000);
    motor(0, 100);
    motor(2, -100);
    msleep(5000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    motor(0, 100);
    motor(2, 100);
    msleep(1000);
    motor(0, -100);
    motor(2, -100);
    msleep(1000);
    enable_servos();
    set_servo_position(1, 1000);
    msleep(2000);
    set_servo_position(1, 0);
    printf("Hello World\n");
    return 0;
}
