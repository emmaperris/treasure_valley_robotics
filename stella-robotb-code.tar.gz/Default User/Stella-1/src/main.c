#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(8150);
    motor(0, -50);
    motor(2, -50);
    msleep(8150);
    printf("Hello World\n");
    return 0;
}
