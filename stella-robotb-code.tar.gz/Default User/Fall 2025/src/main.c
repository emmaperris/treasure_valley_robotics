#include <kipr/wombat.h>
#define HALFPOWER 50
#define HALFPOWERBACK -50
#define BLACK 2000
#define RIGHT 0
#define LEFT 3
#define IRLEFT 1
#define IRRIGHT 0
int main()
{



    //while(analog(IRLEFT) < BLACK){
        // drive to next black line
        //motor(3,HALFPOWER);
        //motor(0,HALFPOWER);
        //msleep(10);
	//}
    //ao();
    // move cone
    // move pomes to work station
    //drive to the black line
	motor(RIGHT,HALFPOWER);
	motor(LEFT,HALFPOWER);
	msleep(2250);
    //tilt
   
    //open arm
    enable_servos();
    set_servo_position(0,800);
    msleep(1000);
    
    set_servo_position(0,0);
    msleep(1000);
    //get the poms
    motor(RIGHT,HALFPOWER);
    motor(LEFT,HALFPOWER);
    msleep(3000);
    //tank turn
    motor(RIGHT,HALFPOWERBACK);
    motor(LEFT,HALFPOWER);
    msleep(1000);
    //drive to the work station
    motor(RIGHT,HALFPOWER);
    motor(LEFT,HALFPOWER);
    msleep(4000);
    //back up
    motor(RIGHT,HALFPOWERBACK);
    motor(LEFT,HALFPOWERBACK);
    msleep(4000);
    //close arm
    set_servo_position(0,800);
    msleep(1000);


    printf("Hello World\n");
    return 0;
}
