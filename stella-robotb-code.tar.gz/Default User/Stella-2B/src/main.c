#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(7500);
    motor(0, -50);
    motor(2, 50);
    msleep(900);
    motor(0, 50);
    motor(2, 50);
    msleep(6000);
    motor(0, 50);
    motor(2, -50);
    msleep(1250);
    motor(0, 50);
    motor(2, 50);
    msleep(4000);
    motor(0, 50);
    motor(2, -50);
    msleep(1500);
    motor(0, 50);
    motor(2, 50);
    msleep(8000);
    motor(0, 50);
    motor(2, -50);
    msleep(1500);
    motor(0, 50);
    motor(2, 50);
    msleep(13000);
    motor(0, 50);
    motor(2, -50);
    msleep(1500);
    motor(0, 50);
    motor(2, 50);
    msleep(8000);
    printf("Hello World\n");
    return 0;
}
