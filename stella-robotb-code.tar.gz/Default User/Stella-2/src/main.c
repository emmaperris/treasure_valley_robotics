#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(3500);
    motor(0, -50);
    motor(2, 50);
    msleep(600);
    motor(0, 50);
    motor(2, 50);
    msleep(6000);
    motor(0, 50);
    motor(2, -50);
    msleep(2500);
    motor(0, 50);
    motor(2, 50);
    msleep(5000);
    motor(0, 50);
    motor(2, -50);
    msleep(1000);
    motor(0, 50);
    motor(2, 50);
    msleep(3000);
    motor(0, 50);
    motor(2, -50);
    msleep(1000);
    motor(0, 50);
    motor(2, 50);
    msleep(6000);
    printf("Hello World\n");
    return 0;
}
