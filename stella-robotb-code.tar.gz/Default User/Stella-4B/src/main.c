#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(5000);
    motor(0, 50);
    motor(2, -50);
    msleep(700);
    motor(0, 50);
    motor(2, 50);
    msleep(1000);
    motor(0, 20);
    motor(2, 50);
    msleep(20000);
    motor(0, 35);
    motor(2, 50);
    msleep(2500);
    motor(0, -50);
    msleep(700);
    motor(0, 50);
    motor(2, 50);
    msleep(2500);
    motor(0, 50);
    motor(2, 20);
    msleep(11500);
    motor(0, 50);
    motor(2, 50);
    msleep(3500);
    motor(0, 60);
    motor(2, 20);
    msleep(18000);
    motor(0, 50);
    motor(2, 50);
    msleep(7000);
    printf("Hello World\n");
    return 0;
}
