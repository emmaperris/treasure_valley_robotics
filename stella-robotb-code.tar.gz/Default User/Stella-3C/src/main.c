#include <kipr/wombat.h>

int main()
{
    motor(0, 50);
    motor(2, 50);
    msleep(3000);
    motor(0, -50);
    motor(2, 50);
    msleep(3300);
    motor(0, -50);
    motor(2, -50);
    msleep(2000);
    motor(0, 50);
    motor(2, 50);
    msleep(6000);
    motor(0, -50);
    motor(2, -50);
    msleep(10000);
    motor(0, -50);
    motor(2, 50);
    msleep(850);
    motor(0, -50);
    motor(2, -50);
    msleep(1500);
    motor(0, 50);
    motor(2, 50);
    msleep(1500);
    motor(0, 50);
    motor(2, -50);
    msleep(850);
    motor(0, 50);
    motor(2, 50);
    msleep(10000);
    printf("Hello World\n");
    return 0;
}
